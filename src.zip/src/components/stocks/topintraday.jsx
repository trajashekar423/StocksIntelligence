export default function TopIntraday({ activeTab, onChange }) {
  const tabs = [
    { key: 'scanner', label: 'Scanner' },
    { key: 'tomorrow', label: 'Tomorrow Intraday' },
    { key: 'avoid', label: 'Avoid Today' },
    { key: 'top', label: 'Top Gainers' },
    { key: 'most', label: 'MOST ACTIVE' },
    { key: 'mystocks', label: 'MyStocks' },
    { key: 'cupid', label: 'CUPID' },
    { key: 'basic-industry', label: 'Basic Industry' },
    { key: 'personal-care', label: 'Personal Care' },
  ];

  return (
    <div className="btn-group btn-group-sm" role="tablist" aria-label="Stocks tabs">
      {tabs.map(({ key, label }) => (
        <button
          key={key}
          type="button"
          className={`btn btn-outline-primary ${activeTab === key ? 'active' : ''}`}
          onClick={() => onChange?.(key)}
        >
          {label}
        </button>
      ))}
    </div>
  );
}
