import Stocks from '../components/stocks/Stocks';

export default function StocksPage() {
  return (
    <div>
      <div className="pg-header">
        <h5 className="pg-title">Intraday Stocks</h5>
        <p className="pg-sub">TOP 10 NSE intraday bullish scanner</p>
      </div>
      <div className="pg-card">
        <div className="pg-card-body">
          <Stocks />
        </div>
      </div>
    </div>
  );
}
